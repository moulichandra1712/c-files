using System;

namespace MyApplication
{
    class program
    {
        static void Main(string[]args)
        {
            string fristName ="mouli";
            string lastName ="chandra";
            string fullName =fristName +lastName;
            Console.WriteLine(fullName);
        }
    }
}