using System;

namespace MyApplication
{
    class program
    {
        static void Main(string[]args)
        {
            Console.WriteLine(Math.Sqrt(225));
        }
    }
}