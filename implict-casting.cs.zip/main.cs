using System;

namespace MyApplication
{
    class program
    {
        static void Main(string[]args)
        {
        int myInt =40;
        double  myDouble =myInt;
        Console.WriteLine(myInt);
        Console.WriteLine(myDouble);
        
        }
        
        
    }
}