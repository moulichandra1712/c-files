using System;

namespace MyApplication
{
    class program
    {
        static void Main (string[]args)
        {
            int x=10;
            int y=30;
            Console.WriteLine (x+y);
        }
    }
}

