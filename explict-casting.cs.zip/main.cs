using System;

namespace MyApplication
{
    class program
    {
        static void Main(string[]args)
        {
            double myDouble =9.445;
            int myInt=(int) myDouble;
            Console.WriteLine(myDouble);
            Console.WriteLine(myInt);
        }
    }
}