  using System;

namespace MyApplication
{
    class program
    {
        static void Main (string []args)
        {
            int x=20;
            int y = 30;
            int z=x+y;
            Console.WriteLine(z);
        }
    }
}
