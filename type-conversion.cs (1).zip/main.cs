using System;

namespace MyApplication
{
    class program
    {
        static void Main(string[]args)
        {
            int myInt =10;
            double  myDouble =5.345;
            bool myBool=true;
            Console.WriteLine(Convert.ToString(myInt));
            Console.WriteLine(Convert.ToDouble(myInt));
            Console.WriteLine(Convert.ToInt32(myDouble));
            Console.WriteLine(Convert.ToString(myBool));
        }
    }
}