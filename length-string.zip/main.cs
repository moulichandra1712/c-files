using System;

namespace MyApplication
{
    class program
    {
        static void Main(string[]args)
        {
            string txt ="chandramouli is smartgig dotnet develpor";
            Console.WriteLine("length of string:"+txt.Length);
        }
    }
}