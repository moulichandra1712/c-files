using System;

namespace MyApplication
{
    class program 
    {
        
    
    static void Main (string []args)
    {
        string name ="chandramouli";
        Console.Write(name);
    }
    }
}