using System;

namespace MyApplication
{
    class program
    {
        static void Main(string[]args)
        {
            Console.WriteLine("Enter username:");
            string userName= Console.ReadLine();
            Console.WriteLine("username is:" + userName);
            Console.WriteLine("enter mailid:");
            string userid=Console.ReadLine();
            Console.WriteLine("mailid is:" +userid);
        }
    }
}