using System;

namespace MyApplication
{
    class program 
    {
        static void Main(string[]args)
        {
            Console.WriteLine(Math.Min(10,23));
        }
    }
}