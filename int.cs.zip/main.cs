using System;

namespace MyApplication 
{
    class program 
    {
        static void Main (string[]args)
        {
         int myNum =23;
         Console.Write("myNum");
        }
        
    }
}