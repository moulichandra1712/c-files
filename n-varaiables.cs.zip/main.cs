using System;

namespace MyApplication
{
    class program
    {
        static void Main(string[]args)
        {
            int a=20,b=30,c=34;
            Console.WriteLine(a+b+c);
        }
    }
}